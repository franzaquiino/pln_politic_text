<h1>Politica</h1>

## Libraries

* Python
* Flask
* Pandas
* Bootstrap

## Thanks
